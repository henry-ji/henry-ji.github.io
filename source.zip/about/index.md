---
title: 关于
type: about
---
<center>
这里是 Henry_ji 的个人博客站
</center>
<center>
欢迎大家通过我的邮箱：
</center>
<center>
henry_ji2008@foxmail.com
</center>
<center>
与我交流，共同进步！
</center>